/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.touchpay.au.frauddetection;

import com.touchpay.au.info.CreditTransaction;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import org.apache.log4j.Logger;

/**
 *
 * @author nalwyn
 */
public class FraudDetection {

    private static final Logger log = Logger.getLogger(FraudDetection.class.getName());
    private static final String DATA_FOLDER = "/home/nalwyn/code/experiment/FraudDetection/data/";
    private static final String DATA_FILENAME = "touchpay.csv";
    private static final String PIPE_STRING = "|";
    private static final String COMMA_STRING = ",";
    private final BigDecimal PRICE_THRESHOLD = new BigDecimal("2000.00");

    private final Map<String,List<CreditTransaction>> creditCardMap = new HashMap();
            
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            FraudDetection fraudDetection = new FraudDetection();
            fraudDetection.buildTouchPayTransactions();
        } catch (Exception exc) {
            log.error(exc.getMessage());
            System.exit(1);
        }
    }

    private void buildTouchPayTransactions() throws FileNotFoundException, IOException, ParseException{
        readData();
        validateHashMapListing();
    }

    private void readData() throws ParseException {
        creditCardMap.clear();
        try (Scanner touchPayScanner = new Scanner(new File(DATA_FOLDER + DATA_FILENAME))) {
            while (touchPayScanner.hasNextLine()) {
                String[] transactionDetails = touchPayScanner.next().split(COMMA_STRING);
                if (transactionDetails.length >= 2) {
                    buildCardHashMap(transactionDetails);
                }
            }
        } catch (FileNotFoundException exc) {
            System.out.println("FileNotFoundException : " + exc.getMessage());
            log.error("FileNotFoundException : " + exc.getMessage());
        } catch (NoSuchElementException exc) {
            System.out.println("NoSuchElementException : End of File with no data");
            log.error("NoSuchElementException : End of File with no data");
        }
    }

    private void buildCardHashMap(String[] transactionDetails) throws ParseException {
        String hashedCardNumber = transactionDetails[0].trim();
        String transactionDateTime = transactionDetails[1].trim();
        BigDecimal cardAmount = new BigDecimal(transactionDetails[2].trim());
        CreditTransaction creditTransDetails = new CreditTransaction(hashedCardNumber, transactionDateTime, cardAmount);
        System.out.println("Transaction Detail : " + hashedCardNumber + PIPE_STRING + transactionDateTime +  PIPE_STRING + 
                cardAmount +  PIPE_STRING + creditTransDetails.getTransLogDate() +  PIPE_STRING + creditTransDetails.getCutOffDate());

        checkCreditTransDetailsExist(creditTransDetails);
    }

    private void checkCreditTransDetailsExist(CreditTransaction creditTransaction) {
        List<CreditTransaction> cTransactionListing = new ArrayList<>();
        List<CreditTransaction> tempCreditListing = (List<CreditTransaction>) creditCardMap.get(creditTransaction.getHashedCardNumber());
        if (tempCreditListing != null) { 
            cTransactionListing = tempCreditListing;
        }
        cTransactionListing.add(creditTransaction);
        creditCardMap.put(creditTransaction.getHashedCardNumber(), cTransactionListing);
    }

    private void validateHashMapListing() {
        //Iterate the hash map for each card no and validate the transactions with the threshold amount.
        creditCardMap.forEach((hashedCardNo, cTransactionListing) -> {
            System.out.println((hashedCardNo + " :  " + cTransactionListing));
            List<CreditTransaction> tCreditListing = cTransactionListing;
            Collections.sort(tCreditListing);
            if (validateCardListing(tCreditListing, PRICE_THRESHOLD) == true) {
                System.out.println("Credit card transaction is valid.");
            } else {
                System.out.println("Credit card transaction is not valid.");
            }
        });
    }

    public boolean validateCardListing(List<CreditTransaction> tCreditListing, BigDecimal PRICE_THRESHOLD) {
        boolean validCard = true;
        for (int i = 0; i < tCreditListing.size(); i++) {
            int logId = i;
            CreditTransaction cTransactionDetail = (CreditTransaction)tCreditListing.get(i);
            BigDecimal totalCreditAmount = get24HourCreditTotal(tCreditListing, logId);
            if (totalCreditAmount.compareTo(PRICE_THRESHOLD) == 1) {
                System.out.println("Credit card " + cTransactionDetail.getHashedCardNumber() + 
                        " has exceeded the threshold amount of " + PRICE_THRESHOLD + ". The total amount is " + totalCreditAmount + ".");
                validCard = false;
            } else {
                System.out.println("Transaction is valid for credit card " + cTransactionDetail.getHashedCardNumber());  
            }
            
        }
        return validCard;
    }

    public BigDecimal get24HourCreditTotal(List<CreditTransaction> tCreditListing, int logId) {
        BigDecimal totalCreditAmount = new BigDecimal(0);
        if (tCreditListing.size() >= logId) {
            CreditTransaction cTransactionDetail = (CreditTransaction)tCreditListing.get(logId);
            BigDecimal creditAmount = new BigDecimal(cTransactionDetail.getCardAmount().toString());
            totalCreditAmount = totalCreditAmount.add(creditAmount);
            Date cutOffDate = cTransactionDetail.getCutOffDate();
            logId ++;
            for (int i = logId; i < tCreditListing.size(); i++) {
                CreditTransaction creditLogDetail = (CreditTransaction)tCreditListing.get(i);
                if (creditLogDetail.getTransLogDate().before(cutOffDate)) {
                    creditAmount = new BigDecimal(creditLogDetail.getCardAmount().toString());
                    totalCreditAmount = totalCreditAmount.add(creditAmount);
                    //System.out.println("Current total : " + totalCreditAmount + " date : " + creditLogDetail.getTransLogDate());
                }

            }
            System.out.println("Net total : " + totalCreditAmount + " date : " + cTransactionDetail.getTransLogDate());
        }
        return totalCreditAmount;
    }
}
