/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.touchpay.au.util;

import com.touchpay.au.info.CreditTransaction;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nalwyn
 */
public class FraudUtils {

    static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yy HH:mm");
    
    public static Date getFormattedTransactionDateTime(String transactionDateTime) {
        Date tCreditDate = null;
        try {
            String[] tempDate = transactionDateTime.split("T");
            tCreditDate = simpleDateFormat.parse(tempDate[0] + " " + tempDate[1]);
        } catch (ParseException exc) {
            System.out.println(exc.getMessage());
            Logger.getLogger(CreditTransaction.class.getName()).log(Level.SEVERE, null, exc);
        }
        return tCreditDate;
    }

    public static Date getFormattedCutOffDate(Date transLogDate) {
        Calendar tCutOffDate = Calendar.getInstance();
        tCutOffDate.setTime(transLogDate);
        tCutOffDate.add(Calendar.HOUR, 24);
        return tCutOffDate.getTime();
    }
}
