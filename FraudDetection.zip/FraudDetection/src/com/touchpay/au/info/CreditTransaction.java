/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.touchpay.au.info;

import com.touchpay.au.util.FraudUtils;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nalwyn
 */
public class CreditTransaction implements Comparable<CreditTransaction> {
    
    private String hashedCardNumber;
    private String transactionDateTime;
    private BigDecimal cardAmount;
    private Date transLogDate;
    private Date cutOffDate;
    private SimpleDateFormat simpleDateFormat;

    public CreditTransaction() {
        this.simpleDateFormat = new SimpleDateFormat("dd/MM/yy HH:mm");
    }

    public CreditTransaction(String hashedCardNumber, String transactionDateTime, BigDecimal cardAmount) throws ParseException {
        this.simpleDateFormat = new SimpleDateFormat("dd/MM/yy HH:mm");
        this.hashedCardNumber = hashedCardNumber;
        this.transactionDateTime = transactionDateTime;
        this.cardAmount = cardAmount;
        this.transLogDate = FraudUtils.getFormattedTransactionDateTime(transactionDateTime);
        this.cutOffDate = FraudUtils.getFormattedCutOffDate(this.transLogDate);
    }

    public String getHashedCardNumber() {
        return hashedCardNumber;
    }

    public void setHashedCardNumber(String hashedCardNumber) {
        this.hashedCardNumber = hashedCardNumber;
    }

    public String getTransactionDateTime() {
        return transactionDateTime;
    }

    public void setTransactionDateTime(String transactionDateTime) {
        this.transactionDateTime = transactionDateTime;
    }

    public BigDecimal getCardAmount() {
        return cardAmount;
    }

    public void setCardAmount(BigDecimal cardAmount) {
        this.cardAmount = cardAmount;
    }

    public Date getTransLogDate() {
        return transLogDate;
    }

    public void setTransLogDate(Date transLogDate) {
        this.transLogDate = transLogDate;
    }

    public Date getCutOffDate() {
        return cutOffDate;
    }

    public void setCutOffDate(Date cutOffDate) {
        this.cutOffDate = cutOffDate;
    }

    @Override
    public int compareTo(CreditTransaction creditTransaction) {
        return this.getTransLogDate().compareTo(creditTransaction.getTransLogDate());
    }
}
