/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.touchpay.au.util.test;

import com.touchpay.au.util.FraudUtils;
import java.util.Date;
import junit.framework.TestCase;
import org.apache.log4j.Logger;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 *
 * @author nalwyn
 */
public class FraudUtilsTest {
    
    private static final Logger log = Logger.getLogger(FraudUtilsTest.class.getName());

    protected void setUp() throws Exception {
        System.out.println("Set Up");
    }

    protected void tearDown() throws Exception {
        System.out.println("Tear Down");
    }

    @Test
    public void test1FormattedTransactionDateTime() {
        String test1Date = "29/04/14T13:15";
        Date formattedTest1Date = FraudUtils.getFormattedTransactionDateTime(test1Date);
        System.out.println("test1FormattedTransactionDateTime date is " + formattedTest1Date.toString());
        assertEquals(formattedTest1Date.toString(), "Tue Apr 29 13:15:00 AEST 2014");
    }

    @Test
    public void test2FormattedTransactionDateTime() {
        String test2Date = "30/04/14T13:15";
        Date formattedTest2Date = FraudUtils.getFormattedTransactionDateTime(test2Date);
        System.out.println("test2FormattedTransactionDateTime date is " + formattedTest2Date.toString());
        assertEquals(formattedTest2Date.toString(), "Wed Apr 30 13:15:00 AEST 2014");
    }

    @Test
    public void test1FormattedCutOff() {
        String test1Date = "30/04/14T13:15";
        Date formattedTest1Date = FraudUtils.getFormattedTransactionDateTime(test1Date);
        Date cutoffTest1Date = FraudUtils.getFormattedCutOffDate(formattedTest1Date);
        System.out.println("test1FormattedCutOff date is " + cutoffTest1Date.toString());
        assertEquals(cutoffTest1Date.toString(), "Thu May 01 13:15:00 AEST 2014");
    }

    @Test
    public void test2FormattedCutOff() {
        String test1Date = "01/05/14T12:15";
        Date formattedTest1Date = FraudUtils.getFormattedTransactionDateTime(test1Date);
        Date cutoffTest1Date = FraudUtils.getFormattedCutOffDate(formattedTest1Date);
        System.out.println("test1FormattedCutOff date is " + cutoffTest1Date.toString());
        assertEquals(cutoffTest1Date.toString(), "Fri May 02 12:15:00 AEST 2014");
    }
}
