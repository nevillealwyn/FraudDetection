/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.touchpay.au.frauddetection.test;

import com.touchpay.au.frauddetection.FraudDetection;
import com.touchpay.au.info.CreditTransaction;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 *
 * @author nalwyn
 */
public class FraudDetectionTest {

    private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(FraudDetectionTest.class.getName());
    List<CreditTransaction> cTransactionListing = new ArrayList<>();        
    CreditTransaction creditTransDetails;
    FraudDetection fDetect;
    
    public FraudDetectionTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
        fDetect = new FraudDetection();
            /*
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "29/04/14T13:15", new BigDecimal("100.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "29/04/14T18:15", new BigDecimal("155.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "30/04/14T10:15", new BigDecimal("839.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "30/04/14T11:15", new BigDecimal("120.35"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "30/04/14T12:15", new BigDecimal("614.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "30/04/14T14:15", new BigDecimal("230.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "01/05/14T08:15", new BigDecimal("302.35"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "01/05/14T08:45", new BigDecimal("389.30"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "01/05/14T09:55", new BigDecimal("923.20"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "01/05/14T10:15", new BigDecimal("243.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "01/05/14T11:05", new BigDecimal("205.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "01/05/14T14:10", new BigDecimal("534.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "01/05/14T18:15", new BigDecimal("124.15"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "01/05/14T18:45", new BigDecimal("582.00"));
            cTransactionListing.add(creditTransDetails);
            */
    }

    @After
    public void tearDown() {
    }

    @Test
    public void test1ValidateCardListing() {
        try {
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "29/04/14T13:15", new BigDecimal("100.00"));
            cTransactionListing.add(creditTransDetails);
        } catch (ParseException exc) {
            System.out.println("ParseException error : " + exc.getMessage());
            log.error("ParseException error : " + exc.getMessage());
        }
        assertTrue(fDetect.validateCardListing(cTransactionListing, new BigDecimal("100")));
    }

    @Test
    public void test2ValidateCardListing() {
        try {
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "29/04/14T13:15", new BigDecimal("100.00"));
            cTransactionListing.add(creditTransDetails);
        } catch (ParseException exc) {
            System.out.println("ParseException error : " + exc.getMessage());
            log.error("ParseException error : " + exc.getMessage());
        }
        assertFalse(fDetect.validateCardListing(cTransactionListing, new BigDecimal("10")));
    }
    
    @Test
    public void test124HourCreditTotal() {
        try {
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "29/04/14T13:15", new BigDecimal("100.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "29/04/14T18:15", new BigDecimal("155.00"));
            cTransactionListing.add(creditTransDetails);
        } catch (ParseException exc) {
            System.out.println("ParseException error : " + exc.getMessage());
            log.error("ParseException error : " + exc.getMessage());
        }
        BigDecimal totalCreditAmount = fDetect.get24HourCreditTotal(cTransactionListing, 0);
        assertEquals(totalCreditAmount, new BigDecimal("255.00"));
    }
    
    @Test
    public void test224HourCreditTotal() {
        try {
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "29/04/14T13:15", new BigDecimal("100.00"));
            cTransactionListing.add(creditTransDetails);
            creditTransDetails = new CreditTransaction("19d7ce2f43e35fa57d1abf8b1e2", "29/04/14T18:15", new BigDecimal("155.00"));
            cTransactionListing.add(creditTransDetails);
        } catch (ParseException exc) {
            System.out.println("ParseException error : " + exc.getMessage());
            log.error("ParseException error : " + exc.getMessage());
        }
        BigDecimal totalCreditAmount = fDetect.get24HourCreditTotal(cTransactionListing, 1);
        assertEquals(totalCreditAmount, new BigDecimal("155.00"));
    }
}
